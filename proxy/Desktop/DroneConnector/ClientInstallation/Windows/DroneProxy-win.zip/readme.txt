
Requirements:
-------------
Java 8

Linux / Windows:
----------------
Execute "install" file and verify installation is being executed and successfuilly.
Then, execute "run" file to start the server
